Readme for Low frequency SDR revision 1

Formerly "ADS_1602_rev_0"
changes from ADS_1602_rev_0 are as follows;

9/17/2022

All schematic symbols are linked from a directory within the LF_SDR project folder. 

datasheets for all semiconductors are within the datasheet folder in the project folder.  
clock is OH300-50503CF-040.0M

Made a proper (not old style, editable) symbol for the ADS_1602.
Started adding and numbering they bypass capacitors, smaller values first (0u1 and 1u) 
Numbers increasing along with ADC pin number.  
This is for the first 12 pins

9/18/2022

The clock buffer is removed due to lack of availability of part
The clock and ADC no longer have seperate power (may be changed in a later rev.)

The OH300 symbol is edited to specify no connection on vtune. 
The VCOCXO model is not used, this pin is NC

The transformer symbol was updated to natively have the correct pin count

The transient suppression diode was removed (just don't hook it up to stupid stuff)

Changed voltage regulators to all LM317, to220 for VDDA, VDD, Vdrive, to92 for Vcm
Vcm regulator fed from VDDA instead of main input. 

       SCHEMATIC NOTES
       
Voltages on the board are :
	Vunreg-	>7vdc
	VDDA-	5vdc
	VDD-	3vdc
	Vdrive-	3.3vdc
	Vcm-	1.5vdc
VDDA and VDD have their own power plane
Vdrive and Vcm are routed on the VDD plane 	
       
the REFEN pin is pulled low by tying to ground.  this enables the internal reference. 
There is no external reference on the board.  

all bypass caps are the same.  
bypass caps use an 0603 (1608 metric) handsoldering pad and SMD ceramic capacitors
X7R dielectric caps by KEMET, datasheet in folder

resistors use an 1206 (3216 metric) handsoldering pad and SMD ceramic capacitors wherever possible

Mounting holes are considered THT pads, and are through plated and connected to AGND
mounting holes form a 90mm square (5mm in from the corners in both axes)


		PCB FEATURES
		
The board is 100 mm square, will be sent to JLCPCB for fab. 

top layer is signal for bot analog and digital
second layer is ground (analog and digital are shared)
third layer is avdd
fourth layer is dvdd and clock power


